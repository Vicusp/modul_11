# learn-js
js examples for fast learning
